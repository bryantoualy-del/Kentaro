# Import Kobe pour Obsidian

Dans Obsidian, lance la commande **Importer une session de la Compagnie** ou touche l’icône lune.

Sélectionne ce ZIP, vérifie l’aperçu puis confirme. Le plugin classe automatiquement la session, les fiches PNJ, les portraits et le reçu d’import dans le coffre actif.

Le traitement est local et aucune fiche PNJ existante n’est écrasée.
