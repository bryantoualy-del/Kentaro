# Import Kobe — 2026-11-05

- **Session :** [[2026-11-05 — Le retour à Qorrashi]]
- **Identifiant :** `kobe-session-e8cd589f-894e-4631-8018-b12d717b113c`
- **PNJ suivis :** 2
- **Nouvelles fiches proposées :** 1
- **Portraits :** 1
- **Export réalisé :** 05/11/2026 08:38:38

> Les PNJ préparés mais absents ne sont pas exportés. Les simples mentions restent dans la session.
