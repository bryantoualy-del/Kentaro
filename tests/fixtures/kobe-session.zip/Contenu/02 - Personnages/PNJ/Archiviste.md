---
type: pnj
kobe_id: "8520ca53-dcf1-4985-8a04-679ed2b3953d"
aliases: []
race:
genre:
groupe:
lieu:
statut: "actif"
relation_kobe: "Inconnu"
premiere_rencontre: "2026-11-05"
illustration: "PNJ - Archiviste - ecdcd551.jpg"
tags:
  - pnj
---
# Archiviste

> [!infobox]
> ![[PNJ - Archiviste - ecdcd551.jpg|coverhsmall]]

## En bref

_À compléter._

## Ce que Kobe sait

- **Statut :** Inconnu
- **Relation :** Inconnu

## Motivation

- À découvrir.

## Relations

- [[Kobe]]

## Secrets ou incertitudes

- [ ] À confirmer :

## Apparitions

- [[2026-11-05 — Le retour à Qorrashi]]
