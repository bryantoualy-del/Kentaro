---
type: session
kobe_id: "kobe-session-e8cd589f-894e-4631-8018-b12d717b113c"
date: 2026-11-05
personnage: Kobe
lieux: []
pnj: ["Roark", "Archiviste"]
resume: ""
tags:
  - session
  - kobe
---
# 2026-11-05 — Le retour à Qorrashi

## Notes de séance

Retrouver la piste de Jorakai.

## Chronologie

- **PNJ · [[Roark]] · Localisation** — Vu aux Trois Soupapes.

## Rencontres

| PNJ | Statut | Relation / conséquence |
| --- | --- | --- |
| [[Roark]] | Actif | Inconnu |
| [[Archiviste]] | Inconnu | Inconnu |

### Visages de la session

![[PNJ - Archiviste - ecdcd551.jpg|160]]

## Découvertes

_Aucune découverte consignée._

## Décisions et promesses

_Aucune décision consignée._

## Combat et ressources

> [!note]- Journal mécanique — 3 événements
> Jet privé · Persuasion · adv · d20 4 / 17 · bonus 13 = 30
> Jet privé · Représentation · normal · d20 11 · bonus 13 = 24
> Jet privé · Sauvegarde Dextérité · normal · d20 12 · bonus 6 = 18

## À préparer pour la prochaine session

- [ ] À compléter.
