---
type: pnj
kentaro_id: "d0c54915-ed13-4ca1-b936-7d22d5281b47"
aliases: []
race:
genre:
groupe:
lieu:
statut: "actif"
relation_kentaro: "Inconnu"
premiere_rencontre: "2026-11-05"
illustration: 
tags:
  - pnj
---
# Roark

## En bref

La Compagnie le connaît déjà.

## Ce que Kentaro sait

- **Statut :** Inconnu
- **Relation :** Inconnu

## Motivation

- À découvrir.

## Relations

- [[Kentaro]]

## Secrets ou incertitudes

- [ ] À confirmer :

## Apparitions

- [[2026-11-05 — Session du 05-11-2026]]
